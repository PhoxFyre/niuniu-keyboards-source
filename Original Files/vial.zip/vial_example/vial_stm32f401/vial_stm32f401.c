/* SPDX-License-Identifier: GPL-2.0-or-later */

#include "vial_stm32f401.h"
