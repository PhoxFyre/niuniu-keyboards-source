/* SPDX-License-Identifier: GPL-2.0-or-later */

#include "vial_atmega32u4.h"
